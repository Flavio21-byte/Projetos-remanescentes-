
import json
import os

ARQUIVO = "contatos.json"

def carregar_contatos():
    if os.path.exists(ARQUIVO):
        with open(ARQUIVO, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def salvar_contatos(contatos):
    with open(ARQUIVO, "w", encoding="utf-8") as f:
        json.dump(contatos, f, indent=4, ensure_ascii=False)

def adicionar_contato(contatos):
    nome = input("Nome: ").strip()
    telefone = input("Telefone: ").strip()
    email = input("E-mail: ").strip()
    contato = {"nome": nome, "telefone": telefone, "email": email}
    contatos.append(contato)
    salvar_contatos(contatos)
    print("✅ Contato adicionado com sucesso!")

def listar_contatos(contatos):
    if not contatos:
        print("⚠️ Nenhum contato salvo.")
        return
    print("\n📇 Lista de Contatos:")
    for i, c in enumerate(contatos, 1):
        print(f"{i}. {c['nome']} | 📞 {c['telefone']} | 📧 {c['email']}")

def buscar_contato(contatos):
    termo = input("Digite o nome para buscar: ").strip().lower()
    resultados = [c for c in contatos if termo in c["nome"].lower()]
    if resultados:
        print("\n🔍 Resultados da busca:")
        for c in resultados:
            print(f"{c['nome']} | 📞 {c['telefone']} | 📧 {c['email']}")
    else:
        print("❌ Nenhum contato encontrado.")

def remover_contato(contatos):
    nome = input("Digite o nome do contato a remover: ").strip().lower()
    novos_contatos = [c for c in contatos if nome not in c["nome"].lower()]
    if len(novos_contatos) != len(contatos):
        salvar_contatos(novos_contatos)
        print("🗑️ Contato removido com sucesso.")
    else:
        print("❌ Nenhum contato com esse nome encontrado.")

def menu():
    contatos = carregar_contatos()
    while True:
        print("\n=== Gerenciador de Contatos ===")
        print("1. Adicionar contato")
        print("2. Listar contatos")
        print("3. Buscar contato")
        print("4. Remover contato")
        print("5. Sair")
        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            adicionar_contato(contatos)
        elif opcao == "2":
            listar_contatos(contatos)
        elif opcao == "3":
            buscar_contato(contatos)
        elif opcao == "4":
            remover_contato(contatos)
            contatos = carregar_contatos()
        elif opcao == "5":
            print("👋 Saindo do programa.")
            break
        else:
            print("❗ Opção inválida.")

if __name__ == "__main__":
    menu()
