Gerenciador de Contatos - Python (Console)
================================================
Este programa permite adicionar, listar, buscar e remover contatos.
Os dados são salvos no arquivo contatos.json automaticamente.
Execute o main.py com Python 3 para começar.
